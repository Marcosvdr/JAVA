package com.hmkcode.api;

public interface MyService {

	void doSomething();
}
