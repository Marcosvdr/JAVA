package com.hmkcode.api;

public interface MyServiceProviderInterface {

	MyService getService();
}
