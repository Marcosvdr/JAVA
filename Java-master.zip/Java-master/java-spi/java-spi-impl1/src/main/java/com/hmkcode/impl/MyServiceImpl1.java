package com.hmkcode.impl;

import com.hmkcode.api.MyService;

public class MyServiceImpl1 implements MyService{

	@Override
	public void doSomething() {
		System.out.println("MyServiceImpl1");
		
	}
}
