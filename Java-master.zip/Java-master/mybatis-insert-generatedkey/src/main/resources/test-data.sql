INSERT INTO myobject_table (objectId, ObjectName ) VALUES (my_sequence.nextVal,'name-1');



