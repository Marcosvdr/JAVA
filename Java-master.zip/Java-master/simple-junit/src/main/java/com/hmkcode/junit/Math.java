package com.hmkcode.junit;

/**
 * Hello world!
 *
 */
public class Math 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
    
    public double sum(double x, double y){
      return x+y;
    }
    public double multiply(double x, double y){
      return x*y;
    }
    public double divide(double x, double y){
      return x/y;
    }
    public double subtract(double x, double y){
      return x - y;
    }
    
    
    
}