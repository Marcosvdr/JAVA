package com.hmkcode;


public interface OnClickListener {
	void onClick(Button button);
	
}
